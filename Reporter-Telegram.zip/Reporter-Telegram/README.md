# Reporter-Telegram
### A powerful tool for reporting channels, groups and accounts ⚠️

### Menu :
<img src="/report/Screenshot_20230805-113406_Pydroid 3.jpg">

#### This tool uses the following methods to report :
* Spam 🔆
* Pornography 🔆
* Violence 🔆
* Child Abuse 🔆
* Other 🔆
* CopyRith 🔆
* Fake 🔆
* Geo Irrelevant 🔆
* Illegal Drugs 🔆
* Personal Details 🔆
### Report Account
<img src="/report/Screenshot_20230805-110416_Pydroid 3.jpg">

### Report Channel
<img src="/report/Screenshot_20230805-113258_Pydroid 3.jpg">

### Report Group [updating]
- It is currently being updated

## tip

- If you accidentally report something, your account will be reported! ❌
- Report any violation you see accordingly
- Any crime committed with this tool is the responsibility of the user ❌
- This is a trial version! ♨️

## Description

### Modules used: 
If installed , pip install {name}
------------------------------------
- telethon 🔰
- prettytable 🔰
- colorama (Required for Windows) 🤓
------------------------------------

## Support from
- Linux ✅
- Windows ✅
- Termux ✅

## Install :

```
git clone https://github.com/esfelurm/Reporter-Telegram
cd Reporter-Telegram
python main.py
```
### this 

If you come across this text, the tool must be logged in once with your account in order to be able to run, enter your number and then enter the account login code. 👇🏻
<img src="/report/20230805_120226.jpg">

Goodbye my friends 
